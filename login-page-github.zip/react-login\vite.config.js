import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  // host: true exposes the dev server on the local network (0.0.0.0),
  // so a phone on the same WiFi can open it via the laptop's IP.
  server: {
    host: true,
  },
})
